import { SerialController } from "./serial";
import { WebSocketController } from "./websocket";
import { DualController } from "./dual";

// Define a common interface for the controllers
export interface CommunicationController {
  connect(): Promise<void>;
  disconnect(): Promise<void>;
  sendCommand(command: string): Promise<string | null>;
  on(event: string, listener: (...args: any[]) => void): this;
  isClientConnected(): boolean;
}

export function createController(): CommunicationController {
  const commMethod = process.env.COMMUNICATION_METHOD || "dual";

  if (commMethod.toLowerCase() === "websocket") {
    console.log("Using WebSocket communication.");
    return new WebSocketController(8080);
  } else if (commMethod.toLowerCase() === "serial") {
    console.log("Using Serial communication.");
    const portName = process.env.SERIAL_PORT_NAME || "/dev/cu.usbmodem1101";
    const baudRate = process.env.BAUD_RATE
      ? parseInt(process.env.BAUD_RATE, 10)
      : 9600;
    return new SerialController(portName, baudRate);
  } else {
    console.log("Using Dual communication (WebSocket + Serial).");
    const portName = process.env.SERIAL_PORT_NAME || "/dev/cu.usbmodem1101";
    const baudRate = process.env.BAUD_RATE
      ? parseInt(process.env.BAUD_RATE, 10)
      : 9600;
    return new DualController(8080, portName, baudRate);
  }
}
