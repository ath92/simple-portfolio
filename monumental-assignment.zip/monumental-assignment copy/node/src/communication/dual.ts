import { SerialController } from "./serial";
import { WebSocketController } from "./websocket";
import { EventEmitter } from "events";

export class DualController extends EventEmitter {
  private serialController: SerialController;
  private wsController: WebSocketController;

  constructor(wsPort: number, serialPortName: string, serialBaudRate: number) {
    super();
    this.wsController = new WebSocketController(wsPort);
    this.serialController = new SerialController(
      serialPortName,
      serialBaudRate,
    );

    this.wsController.on("data", (line: string) => {
      this.emit("data", line);
    });

    this.wsController.on("connection", () => {
      console.log("Browser simulation client connected");
    });

    this.serialController.on("data", (line: string) => {
      this.emit("data", line);
    });
  }

  isClientConnected(): boolean {
    return (
      this.wsController.isClientConnected() ||
      this.serialController.isClientConnected()
    );
  }

  async connect(): Promise<void> {
    console.log("Starting WebSocket server (browser client optional)...");
    console.log("Connecting to Serial...");

    const results = await Promise.allSettled([
      Promise.race([
        this.wsController.connect(),
        new Promise((resolve) => setTimeout(resolve, 1000)),
      ]),
      this.serialController.connect(),
    ]);

    const wsResult = results[0];
    const serialResult = results[1];

    if (wsResult.status === "rejected") {
      console.warn("WebSocket setup failed:", wsResult.reason);
    } else if (this.wsController.isClientConnected()) {
      console.log("WebSocket client connected");
    } else {
      console.log(
        "WebSocket server ready (no client connected yet - this is OK)",
      );
    }

    if (serialResult.status === "rejected") {
      console.warn("Serial connection failed:", serialResult.reason);
    } else {
      console.log("Serial connected successfully");
    }

    if (serialResult.status === "rejected") {
      console.warn(
        "Serial not available - will use WebSocket only when client connects",
      );
    }
  }

  async disconnect(): Promise<void> {
    await Promise.allSettled([
      this.wsController.disconnect(),
      this.serialController.disconnect(),
    ]);
  }

  async sendCommand(command: string): Promise<string | null> {
    const results = await Promise.allSettled([
      this.wsController.sendCommand(command),
      this.serialController.sendCommand(command),
    ]);

    const wsResult = results[0];
    const serialResult = results[1];

    if (wsResult.status === "rejected") {
      console.warn("WebSocket command failed:", wsResult.reason);
    }

    if (serialResult.status === "rejected") {
      console.warn("Serial command failed:", serialResult.reason);
    }

    if (serialResult.status === "fulfilled") {
      return serialResult.value;
    }

    if (wsResult.status === "fulfilled") {
      return wsResult.value;
    }

    return null;
  }
}
