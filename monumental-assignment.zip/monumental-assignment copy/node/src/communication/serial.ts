import { SerialPort } from "serialport";
import { ReadlineParser } from "@serialport/parser-readline";
import { EventEmitter } from "events";

const ACKNOWLEDGEMENT = "OK";

export class SerialController extends EventEmitter {
  private port: SerialPort;
  private parser: ReadlineParser;

  constructor(portName: string, baudRate: number) {
    super();
    this.port = new SerialPort({ path: portName, baudRate, autoOpen: false });
    this.parser = this.port.pipe(new ReadlineParser({ delimiter: "\n" }));
    this.parser.on("data", (line: string) => {
      this.emit("data", line);
    });
  }

  isClientConnected(): boolean {
    return this.port.isOpen;
  }

  connect(): Promise<void> {
    return new Promise((resolve, reject) => {
      this.port.open((err) => {
        if (err) {
          return reject(err);
        }
        resolve();
      });
    });
  }

  disconnect(): Promise<void> {
    return new Promise((resolve, reject) => {
      this.port.close((err) => {
        if (err) {
          return reject(err);
        }
        resolve();
      });
    });
  }

  sendCommand(command: string): Promise<string | null> {
    return new Promise<string | null>((resolve, reject) => {
      let previousResponse: null | string = null;

      // Determine expected ACK based on command
      const commandType = command.split(",")[0].toUpperCase();
      let expectedAck = ACKNOWLEDGEMENT;
      if (commandType === "ROT") {
        expectedAck = "ROT_OK";
      } else if (commandType === "EXT") {
        expectedAck = "EXT_OK";
      }

      const dataHandler = (line: string) => {
        const response = line.trim();
        console.log(`\t<- Response received: ${response}`);

        if (response === expectedAck) {
          this.parser.off("data", dataHandler);
          resolve(previousResponse);
          previousResponse = null;
        } else if (response.startsWith("ERROR:")) {
          this.parser.off("data", dataHandler);
          reject(new Error(`Arduino Error: ${response}`));
        } else {
          previousResponse = response;
        }
      };

      this.parser.on("data", dataHandler);

      const serialData = command + "\n";
      this.port.write(serialData, (err) => {
        if (err) {
          this.parser.off("data", dataHandler);
          reject(new Error("Error writing to serial port: " + err.message));
        }
        console.log(`-> Command sent: ${command}`);
      });
    });
  }
}
