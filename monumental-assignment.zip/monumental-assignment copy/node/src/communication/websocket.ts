import { WebSocketServer, WebSocket } from "ws";
import { EventEmitter } from "events";

const ACKNOWLEDGEMENT = "OK";

export class WebSocketController extends EventEmitter {
  private wss: WebSocketServer;
  private client: WebSocket | null = null;

  constructor(port: number) {
    super();
    this.wss = new WebSocketServer({ port });

    this.wss.on("connection", (ws) => {
      console.log("WebSocket client connected");
      this.client = ws;

      ws.on("message", (message: Buffer) => {
        const line = message.toString();
        this.emit("data", line);
      });

      ws.on("close", () => {
        console.log("WebSocket client disconnected");
        this.client = null;
      });

      ws.on("error", (error) => {
        console.warn("WebSocket error:", error.message);
        this.client = null;
      });

      this.emit("connection", ws);
    });
  }

  isClientConnected(): boolean {
    return !!this.client;
  }

  connect(): Promise<void> {
    return new Promise((resolve) => {
      if (this.client) {
        return resolve();
      }
      this.once("connection", () => {
        console.log("Client connected, resolving connect promise.");
        resolve();
      });
    });
  }

  disconnect(): Promise<void> {
    return new Promise((resolve) => {
      if (this.client) {
        this.client.close();
      }
      this.wss.close(() => {
        resolve();
      });
    });
  }

  sendCommand(command: string): Promise<string | null> {
    return new Promise<string | null>((resolve, reject) => {
      let previousResponse: string | null = null;
      if (!this.client || this.client.readyState !== WebSocket.OPEN) {
        return resolve(null);
      }

      // Determine expected ACK based on command
      const commandType = command.split(",")[0].toUpperCase();
      let expectedAck = ACKNOWLEDGEMENT;
      if (commandType === "ROT") {
        expectedAck = "ROT_OK";
      } else if (commandType === "EXT") {
        expectedAck = "EXT_OK";
      }

      const dataHandler = (line: string) => {
        const response = line.trim();
        // console.log(`\t<- WebSocket response received: ${response}`);

        if (response === expectedAck) {
          this.off("data", dataHandler);
          resolve(previousResponse);
        } else if (response.startsWith("ERROR:")) {
          this.off("data", dataHandler);
          reject(new Error(`Simulation Error: ${response}`));
        } else {
          previousResponse = response;
        }
      };

      this.on("data", dataHandler);

      this.client.send(command, (err) => {
        if (err) {
          this.off("data", dataHandler);
          this.client = null;
          resolve(null);
        }
        // console.log(`-> WebSocket command sent: ${command}`);
      });
    });
  }
}
