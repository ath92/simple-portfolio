import { createController } from "./communication/index";
import * as readline from "readline";
import Anthropic from "@anthropic-ai/sdk";
import * as svgPathParser from "svg-path-parser";

// --- CONFIGURATION ---
/**
 * The physical distance between the swing joint's pivot and the position where the robot's
 * extension is 0.
 */
const ARM_EXTENSION_OFFSET_MM = 160; //200; // mm

const MICROSTEP_PER_STEP = 256;
const STEPS_180 = 100 * 20; // 200 steps per rev, 20:1 gearbox ratio

const MARGIN_D = 3;
const MARGIN_R = 1;

// arm length + conversion from "robot coordinates"
const MAXD = 1013;
const MAX_D_MM = 470;
const D_CONVERSION = (MAX_D_MM - ARM_EXTENSION_OFFSET_MM) / MAXD;

const SEGMENT_LENGTH = 1;

// --- CONTROLLER SETUP ---

const controller = createController();

// --- CLAUDE API SETUP ---
const anthropic = new Anthropic({
  apiKey: process.env.ANTHROPIC_API_KEY,
});

const microstep_to_rad = (n: number) =>
  (n / STEPS_180 / MICROSTEP_PER_STEP) * Math.PI;
const rad_to_microstep = (n: number) =>
  (n / Math.PI) * STEPS_180 * MICROSTEP_PER_STEP;

// --- MAIN EXECUTION LOGIC ---
// takes coords in robot space (polar with microsteps for rotation (x), steps for extension (y))
async function goToPoint(point: Point) {
  console.log(point, "point");

  await Promise.all([
    controller.sendCommand("ROT," + point[0]),
    controller.sendCommand("EXT," + point[1]),
  ]);
}

type Point = [number, number];

async function drawLine(start: Point, end: Point) {
  console.log("drawline", start, end);
  const diff = [end[0] - start[0], end[1] - start[1]];
  const len = (diff[0] ** 2 + diff[1] ** 2) ** 0.5;
  const num_segments = len / SEGMENT_LENGTH;
  const dist = [diff[0] / num_segments, diff[1] / num_segments];

  const points = Array(Math.round(num_segments))
    .fill(null)
    .map((_, i) => {
      return [start[0] + dist[0] * i, start[1] + dist[1] * i] as Point;
    });

  for (let point of points) {
    await goToPoint(toRobotCoords(point));
  }
}

async function drawPolygon(points: Point[]) {
  console.log("drawPolygon", points);

  if (points.length < 2) {
    throw new Error("Polygon must have at least 2 points");
  }

  for (let i = 0; i < points.length; i++) {
    const start = points[i];
    const end = points[(i + 1) % points.length];
    await drawLine(start, end);
  }
}

function toPolar([x, y]: Point): Point {
  const angle = Math.atan2(x, y);
  const distance_from_origin = (x ** 2 + y ** 2) ** 0.5;

  return [
    angle, // rad
    distance_from_origin, // mm
  ];
}

const normalizeY = (p: Point): Point => [p[0], p[1] + ARM_EXTENSION_OFFSET_MM];

// coords in mm, out in "robot" (microsteps + local unit of extension arm)
function toRobotCoords(p: Point): Point {
  const normalizedY: Point = normalizeY(p);
  const polar = toPolar(normalizedY);

  const rotation_microSteps = rad_to_microstep(polar[0] % Math.PI);
  const distance_steps = (polar[1] - ARM_EXTENSION_OFFSET_MM) / D_CONVERSION;
  return [rotation_microSteps, distance_steps];
}

async function runSquareSequence() {
  console.log("--- Starting Square Sequence ---");

  try {
    await drawLine([20, 20], [20, 80]);
    await drawLine([20, 80], [80, 80]);
    await drawLine([80, 80], [80, 20]);
    await drawLine([80, 20], [20, 20]);
    await controller.sendCommand("STOP");
  } catch (error) {
    console.error("Sequence Failed:", (error as any).message);
  } finally {
    console.log("--- Square Sequence Finished ---");
  }
}

async function generatePolygonFromPrompt(prompt: string): Promise<Point[]> {
  console.log(`Generating polygon from prompt: "${prompt}"`);

  const message = await anthropic.messages.create({
    model: "claude-sonnet-4-5-20250929",
    max_tokens: 1024,
    messages: [
      {
        role: "user",
        content: `You are a robot control system that generates polygon coordinates based on text descriptions.

Given a text prompt, generate a polygon (array of [x, y] points) that represents the described shape.

Requirements:
- Return ONLY a valid JSON array of points in the format: [[x1, y1], [x2, y2], ...]
- Each point is [x, y] where both are numbers in millimeters
- Use a coordinate system where reasonable shapes fit within approximately 20-100mm range
- Do NOT include any explanation, markdown formatting, or additional text
- Just return the raw JSON array

Example prompt: "triangle"
Example response: [[50, 20], [80, 80], [20, 80]]

Now generate a polygon for this prompt: "${prompt}"`,
      },
    ],
  });

  const content = message.content[0];
  if (content.type !== "text") {
    throw new Error("Unexpected response type from Claude");
  }

  const responseText = content.text.trim();
  console.log(`Claude response: ${responseText}`);

  try {
    const points = JSON.parse(responseText) as Point[];

    if (!Array.isArray(points)) {
      throw new Error("Response is not an array");
    }

    if (
      points.some(
        (p) =>
          !Array.isArray(p) ||
          p.length !== 2 ||
          typeof p[0] !== "number" ||
          typeof p[1] !== "number",
      )
    ) {
      throw new Error("Invalid point format in response");
    }

    return points;
  } catch (error) {
    throw new Error(
      `Failed to parse Claude response: ${(error as Error).message}`,
    );
  }
}

function convertSvgPathToPoints(pathData: string): Point[] {
  const commands = svgPathParser.parseSVG(pathData);
  const points: Point[] = [];
  let currentX = 0;
  let currentY = 0;

  for (const cmd of commands) {
    switch (cmd.command) {
      case "moveto":
        currentX = cmd.x ?? currentX;
        currentY = cmd.y ?? currentY;
        points.push([currentX, currentY]);
        break;
      case "lineto":
        currentX = cmd.x ?? currentX;
        currentY = cmd.y ?? currentY;
        points.push([currentX, currentY]);
        break;
      case "horizontal lineto":
        currentX = cmd.x ?? currentX;
        points.push([currentX, currentY]);
        break;
      case "vertical lineto":
        currentY = cmd.y ?? currentY;
        points.push([currentX, currentY]);
        break;
      case "curveto":
        // For cubic bezier curves, we'll sample points along the curve
        const x0 = currentX;
        const y0 = currentY;
        const x1 = cmd.x1 ?? x0;
        const y1 = cmd.y1 ?? y0;
        const x2 = cmd.x2 ?? x0;
        const y2 = cmd.y2 ?? y0;
        const x3 = cmd.x ?? x0;
        const y3 = cmd.y ?? y0;

        // Sample 10 points along the bezier curve
        for (let t = 0.1; t <= 1; t += 0.1) {
          const mt = 1 - t;
          const x =
            mt ** 3 * x0 +
            3 * mt ** 2 * t * x1 +
            3 * mt * t ** 2 * x2 +
            t ** 3 * x3;
          const y =
            mt ** 3 * y0 +
            3 * mt ** 2 * t * y1 +
            3 * mt * t ** 2 * y2 +
            t ** 3 * y3;
          points.push([x, y]);
        }

        currentX = x3;
        currentY = y3;
        break;
      case "smooth curveto":
        // Similar to curveto but with reflected control point
        const sx0 = currentX;
        const sy0 = currentY;
        const sx2 = cmd.x2 ?? sx0;
        const sy2 = cmd.y2 ?? sy0;
        const sx3 = cmd.x ?? sx0;
        const sy3 = cmd.y ?? sy0;

        // For simplicity, approximate with fewer control points
        for (let t = 0.1; t <= 1; t += 0.1) {
          const mt = 1 - t;
          const x = mt ** 2 * sx0 + 2 * mt * t * sx2 + t ** 2 * sx3;
          const y = mt ** 2 * sy0 + 2 * mt * t * sy2 + t ** 2 * sy3;
          points.push([x, y]);
        }

        currentX = sx3;
        currentY = sy3;
        break;
      case "quadratic curveto":
        // Quadratic bezier curve
        const qx0 = currentX;
        const qy0 = currentY;
        const qx1 = cmd.x1 ?? qx0;
        const qy1 = cmd.y1 ?? qy0;
        const qx2 = cmd.x ?? qx0;
        const qy2 = cmd.y ?? qy0;

        for (let t = 0.1; t <= 1; t += 0.1) {
          const mt = 1 - t;
          const x = mt ** 2 * qx0 + 2 * mt * t * qx1 + t ** 2 * qx2;
          const y = mt ** 2 * qy0 + 2 * mt * t * qy1 + t ** 2 * qy2;
          points.push([x, y]);
        }

        currentX = qx2;
        currentY = qy2;
        break;
      case "closepath":
        // Connect back to the first point if needed
        if (points.length > 0) {
          const firstPoint = points[0];
          if (currentX !== firstPoint[0] || currentY !== firstPoint[1]) {
            points.push(firstPoint);
          }
        }
        break;
      // Add more cases as needed for other SVG path commands
    }
  }

  // Flip y-axis: SVG has y pointing down, but we need y pointing up
  // Calculate the bounding box
  if (points.length === 0) {
    return points;
  }

  const minY = Math.min(...points.map((p) => p[1]));
  const maxY = Math.max(...points.map((p) => p[1]));

  // Flip each point's y-coordinate
  const flippedPoints = points.map(([x, y]): Point => [x, maxY - y + minY]);

  return flippedPoints;
}

const rl = readline.createInterface({
  input: process.stdin,
  output: process.stdout,
});

const promptForCommand = async () => {
  rl.question("> ", async (input) => {
    const command = input.trim().toLowerCase();

    if (command === "exit") {
      await controller.disconnect();
      rl.close();
      process.exit(0);
    }

    if (!controller.isClientConnected()) {
      console.log("no client connected");
      promptForCommand();
      return;
    }

    if (command.startsWith("polygon ")) {
      try {
        const jsonStr = input.substring("polygon ".length).trim();
        const points = JSON.parse(jsonStr) as Point[];

        if (!Array.isArray(points)) {
          console.log("Error: Points must be an array");
        } else if (points.some((p) => !Array.isArray(p) || p.length !== 2)) {
          console.log("Error: Each point must be an array of 2 numbers [x, y]");
        } else {
          await drawPolygon(points);
          await controller.sendCommand("STOP");
        }
      } catch (error) {
        console.log(`Error parsing polygon: ${(error as Error).message}`);
      }
      promptForCommand();
      return;
    }

    if (command.startsWith("prompt ")) {
      try {
        const promptText = input.substring("prompt ".length).trim();

        if (!promptText) {
          console.log("Error: Please provide a prompt describing the shape");
          promptForCommand();
          return;
        }

        const points = await generatePolygonFromPrompt(promptText);
        console.log(`Generated polygon with ${points.length} points:`, points);

        await drawPolygon(points);
        await controller.sendCommand("STOP");
      } catch (error) {
        console.log(
          `Error generating polygon from prompt: ${(error as Error).message}`,
        );
      }
      promptForCommand();
      return;
    }

    if (command.startsWith("path ")) {
      try {
        const pathData = input.substring("path ".length).trim();

        if (!pathData) {
          console.log("Error: Please provide an SVG path d parameter value");
          promptForCommand();
          return;
        }

        const points = convertSvgPathToPoints(pathData);
        console.log(`Converted path to ${points.length} points`);

        if (points.length === 0) {
          console.log("Error: No points generated from path");
          promptForCommand();
          return;
        }

        // Draw lines between consecutive points
        for (let i = 0; i < points.length - 1; i++) {
          await drawLine(points[i], points[i + 1]);
        }

        await controller.sendCommand("STOP");
      } catch (error) {
        console.log(`Error drawing path: ${(error as Error).message}`);
      }
      promptForCommand();
      return;
    }

    switch (command) {
      case "square":
        await runSquareSequence();
        break;
      default:
        console.log(`Unknown command: "${command}"`);
        break;
    }

    promptForCommand();
  });
};

controller
  .connect()
  .then(() => {
    if (process.env.COMMUNICATION_METHOD?.toLowerCase() === "websocket") {
      console.log("Server is running and waiting for a client to connect.");
    }
    promptForCommand();
  })
  .catch((err) => {
    console.error("Failed to connect:", err.message);
    process.exit(1);
  });
