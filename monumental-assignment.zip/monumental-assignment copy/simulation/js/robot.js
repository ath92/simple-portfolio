const ARM_BASE_X = 400;
const ARM_BASE_Y = 550;
const PIXELS_PER_MM = 1.5; // Scaling factor for drawing

// Simulation constants
const ROTATION_SPEED = 50000; // microsteps per second
const EXTENSION_SPEED = 100; // units per second

// Physical robot constants (matching index.ts)
const ARM_EXTENSION_OFFSET_MM = 160; // mm - distance from pivot to zero extension
const MAXD = 1013; // maximum extension in robot units
const MAX_D_MM = 470; // maximum extension in millimeters
const D_CONVERSION = (MAX_D_MM - ARM_EXTENSION_OFFSET_MM) / MAXD;
const MICROSTEP_PER_STEP = 256;
const STEPS_180 = 100 * 20; // 200 steps per rev, 20:1 gearbox ratio

export class Robot {
  constructor(canvasContext) {
    this.ctx = canvasContext;

    // State in "robot units"
    this.angleMicrosteps = 0;
    this.extension = 0; // 0 = fully retracted, >0 = extended
    this.penDown = true;

    // For asynchronous movement
    this.activeMovement = null; // { resolve, command, target, duration, startTime }
    this.lastUpdateTime = performance.now();

    // Trail tracking
    this.trail = []; // Array of {x, y} coordinates
    this.lastPenPosition = null; // Track last position when pen was down
  }

  isBusy() {
    return this.activeMovement !== null;
  }

  // --- Asynchronous Movement Methods ---

  setAngle(targetMicrosteps) {
    if (this.isBusy()) {
      return Promise.reject(new Error("Robot is already busy."));
    }
    return new Promise((resolve) => {
      this.activeMovement = {
        resolve,
        command: "ROT",
        target: parseFloat(targetMicrosteps),
      };
    });
  }

  setExtension(targetExtension) {
    if (this.isBusy()) {
      return Promise.reject(new Error("Robot is already busy."));
    }
    return new Promise((resolve) => {
      this.activeMovement = {
        resolve,
        command: "EXT",
        target: parseFloat(targetExtension),
      };
    });
  }

  extend(duration) {
    if (this.isBusy()) {
      return Promise.reject(new Error("Robot is already busy."));
    }
    return new Promise((resolve) => {
      this.activeMovement = {
        resolve,
        command: "OUT",
        duration: parseFloat(duration),
        startTime: performance.now(),
      };
    });
  }

  retract(duration) {
    if (this.isBusy()) {
      return Promise.reject(new Error("Robot is already busy."));
    }
    return new Promise((resolve) => {
      this.activeMovement = {
        resolve,
        command: "IN",
        duration: parseFloat(duration),
        startTime: performance.now(),
      };
    });
  }

  stop() {
    if (this.activeMovement) {
      // Resolve the promise to unblock the command loop, but don't finish the movement.
      this.activeMovement.resolve();
      this.activeMovement = null;
    }
  }

  // --- Animation Loop (called by main.js) ---

  update() {
    const now = performance.now();
    const deltaTime = (now - this.lastUpdateTime) / 1000; // seconds
    this.lastUpdateTime = now;

    if (!this.activeMovement) return;

    const { command, resolve } = this.activeMovement;

    if (command === "ROT") {
      const { target } = this.activeMovement;
      const diff = target - this.angleMicrosteps;
      const step = ROTATION_SPEED * deltaTime;

      if (Math.abs(diff) <= step) {
        this.angleMicrosteps = target;
        this.activeMovement = null;
        resolve();
      } else {
        this.angleMicrosteps += Math.sign(diff) * step;
      }
    } else if (command === "EXT") {
      const { target } = this.activeMovement;
      const diff = target - this.extension;
      const step = EXTENSION_SPEED * deltaTime;

      if (Math.abs(diff) <= step) {
        this.extension = target;
        this.activeMovement = null;
        resolve();
      } else {
        this.extension += Math.sign(diff) * step;
      }

      // Clamp extension
      if (this.extension < 0) this.extension = 0;
    } else if (command === "OUT" || command === "IN") {
      const { startTime, duration } = this.activeMovement;
      const elapsedTime = now - startTime;

      if (elapsedTime >= duration) {
        const direction = command === "OUT" ? 1 : -1;
        // Ensure final position is accurate
        const distanceChange = EXTENSION_SPEED * (duration / 1000);
        this.extension += direction * distanceChange;

        this.activeMovement = null;
        resolve();
      } else {
        const direction = command === "OUT" ? 1 : -1;
        this.extension += direction * EXTENSION_SPEED * deltaTime;
      }

      // Clamp extension
      if (this.extension < 0) this.extension = 0;
    }
  }

  draw() {
    this.ctx.clearRect(0, 0, this.ctx.canvas.width, this.ctx.canvas.height);

    // Convert robot units to canvas coordinates (matching index.ts conversion)
    // Angle: microsteps to radians
    const angleRad =
      (this.angleMicrosteps / (STEPS_180 * MICROSTEP_PER_STEP)) * Math.PI -
      Math.PI / 2;

    // Extension: robot units to millimeters
    const extensionMM = this.extension * D_CONVERSION + ARM_EXTENSION_OFFSET_MM;
    const extensionPixels = extensionMM * PIXELS_PER_MM;

    const armEndX = ARM_BASE_X + Math.cos(angleRad) * extensionPixels;
    const armEndY = ARM_BASE_Y + Math.sin(angleRad) * extensionPixels;

    // Update trail if pen is down
    if (this.penDown) {
      if (this.lastPenPosition) {
        this.trail.push({
          x1: this.lastPenPosition.x,
          y1: this.lastPenPosition.y,
          x2: armEndX,
          y2: armEndY,
        });
      }
      this.lastPenPosition = { x: armEndX, y: armEndY };
    } else {
      this.lastPenPosition = null;
    }

    // Draw the trail
    this.ctx.strokeStyle = "black";
    this.ctx.lineWidth = 2;
    for (const segment of this.trail) {
      this.ctx.beginPath();
      this.ctx.moveTo(segment.x1, segment.y1);
      this.ctx.lineTo(segment.x2, segment.y2);
      this.ctx.stroke();
    }

    // Draw the base
    this.ctx.fillStyle = "grey";
    this.ctx.beginPath();
    this.ctx.arc(ARM_BASE_X, ARM_BASE_Y, 15, 0, 2 * Math.PI);
    this.ctx.fill();

    // Draw the arm
    this.ctx.strokeStyle = "black";
    this.ctx.lineWidth = 5;
    this.ctx.beginPath();
    this.ctx.moveTo(ARM_BASE_X, ARM_BASE_Y);
    this.ctx.lineTo(armEndX, armEndY);
    this.ctx.stroke();

    // Draw the pen
    this.ctx.fillStyle = this.penDown ? "blue" : "red";
    this.ctx.beginPath();
    this.ctx.arc(armEndX, armEndY, 8, 0, 2 * Math.PI);
    this.ctx.fill();
  }

  // --- Getters for reporting state ---

  getState() {
    return {
      angle: this.angleMicrosteps,
      distance: this.extension,
    };
  }
}
