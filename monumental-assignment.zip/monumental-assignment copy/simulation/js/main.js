import { connectToServer, sendMessage } from "./communication.js";
import { Robot } from "./robot.js";

const canvas = document.getElementById("simulationCanvas");
const ctx = canvas.getContext("2d");

const robot = new Robot(ctx);
let isServerConnected = false;

async function processCommand(commandString) {
  if (robot.isBusy()) {
    console.warn("Ignoring command, robot is busy:", commandString);
    // Optionally send a "BUSY" message or just ignore.
    // For now, we'll just ignore to prevent command queue buildup.
    return;
  }

  const [commandID, ...params] = commandString.split(",");

  console.log(`Processing command: ${commandID}`, params);

  try {
    switch (commandID.toUpperCase()) {
      case "ROT":
        await robot.setAngle(params[0]);
        sendAck();
        break;
      case "EXT":
        await robot.setExtension(params[0]);
        sendAck();
        break;
      case "OUT":
        await robot.extend(params[0] || 100);
        sendAck();
        break;
      case "IN":
        await robot.retract(params[0] || 100);
        sendAck();
        break;
      case "STOP":
        robot.stop(); // stop is synchronous
        sendAck();
        break;
      case "DIST": {
        const state = robot.getState();
        sendMessage(String(state.distance));
        sendAck();
        break;
      }
      case "ANGL": {
        const state = robot.getState();
        sendMessage(String(state.angle));
        sendAck();
        break;
      }
      default:
        console.error(`Unknown command received: ${commandID}`);
        sendMessage(`ERROR: Unknown command ${commandID}`);
        break;
    }
  } catch (error) {
    console.error(`Error processing command "${commandString}":`, error);
    sendMessage(`ERROR: ${error.message}`);
  }
}

function sendAck() {
  sendMessage("OK");
}

function animationLoop() {
  robot.update();
  robot.draw();
  requestAnimationFrame(animationLoop);
}

function onServerOpen() {
  isServerConnected = true;
  console.log("Ready to receive commands.");
}

function onServerMessage(message) {
  // The server sends one command at a time, followed by a newline,
  // but the websocket message event gives us the raw string.
  processCommand(message);
}

// --- Main ---
console.log("Starting simulation...");
connectToServer(onServerOpen, onServerMessage);
requestAnimationFrame(animationLoop);
