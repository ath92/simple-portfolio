const WEBSOCKET_URL = "ws://localhost:8080";

let socket;
const messageQueue = [];
let isConnected = false;

const commandCallbacks = new Map();
let messageIdCounter = 0;

export function connectToServer(onOpen, onMessage) {
  socket = new WebSocket(WEBSOCKET_URL);

  socket.addEventListener("open", () => {
    console.log("WebSocket connection established.");
    isConnected = true;
    // Send any queued messages
    messageQueue.forEach((msg) => socket.send(msg));
    messageQueue.length = 0; // Clear the queue
    if (onOpen) {
      onOpen();
    }
  });

  socket.addEventListener("message", (event) => {
    const message = event.data;
    // console.log(`<- Received from server: ${message}`);
    if (onMessage) {
      onMessage(message);
    }
  });

  socket.addEventListener("close", () => {
    console.log("WebSocket connection closed.");
    isConnected = false;
  });

  socket.addEventListener("error", (error) => {
    console.error("WebSocket error:", error);
  });
}

export function sendMessage(message) {
  if (isConnected) {
    socket.send(message);
    // console.log(`-> Sent to server: ${message}`);
  } else {
    console.log(`Queueing message: ${message}`);
    messageQueue.push(message);
  }
}
