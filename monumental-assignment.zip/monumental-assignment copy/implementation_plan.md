# Implementation Plan: Arduino Pen Plotter Control System

This document outlines the plan to refactor the Node.js server, create a WebSocket communication alternative, and build an HTML/Canvas simulation for the Arduino pen plotter.

## Part 1: Refactor Serial Communication in Node.js Server

The goal is to modularize the existing serial communication logic, making the system more flexible and easier to maintain.

1.  **Create a Communication Module Directory:**
    *   Create a new directory: `node/src/communication`.

2.  **Create the Serial Communication Module:**
    *   Create a new file: `node/src/communication/serial.ts`.
    *   This module will encapsulate all logic related to communicating with the Arduino via the serial port.
    *   It will use the `serialport` and `@serialport/parser-readline` packages.

3.  **Define the `SerialController` class:**
    *   The `SerialController` class will manage the serial port connection.
    *   It will have methods like:
        *   `constructor(portName: string, baudRate: number)`: Initializes the serial port and attaches a readline parser.
        *   `connect()`: Opens the connection to the serial port. Returns a promise that resolves when the connection is established.
        *   `disconnect()`: Closes the serial port connection.
        *   `sendCommand(command: string, ...args: (string | number)[]): Promise<string>`: Sends a command to the Arduino and returns a promise that resolves with the response from the firmware.
        *   `on(event: string, listener: (...args: any[]) => void)`: An event emitter to handle asynchronous messages from the firmware (e.g., status updates).

4.  **Refactor `node/src/index.ts`:**
    *   Remove all direct serial port handling code.
    *   Import and instantiate the `SerialController`.
    *   Use the `SerialController` instance to communicate with the Arduino.

## Part 2: Create WebSocket Communication Module

This part involves creating a parallel communication module that uses WebSockets, allowing a web-based simulation to connect.

1.  **Create the WebSocket Communication Module:**
    *   Create a new file: `node/src/communication/websocket.ts`.
    *   This module will implement a WebSocket server using the `ws` package.

2.  **Define the `WebSocketController` class:**
    *   This class will have the same public interface as `SerialController` for consistency.
    *   `constructor(port: number)`: Starts a WebSocket server on the given port.
    *   `connect()`: This method might not be strictly necessary for the server, but will be implemented to match the interface. It will return a promise that resolves when a client connects.
    *   `disconnect()`: Closes the WebSocket server.
    *   `sendCommand(command: string, ...args: (string | number)[]): Promise<string>`: Sends a command to the connected WebSocket client (the simulation) and waits for a response.
    *   `on(event: string, listener: (...args: any[]) => void)`: An event emitter to handle messages from the WebSocket client.

3.  **Implement a Controller Factory:**
    *   Create a new file: `node/src/communication/index.ts`.
    *   This file will contain a factory function that returns either a `SerialController` or a `WebSocketController` instance based on an environment variable.
    *   Example:
        ```typescript
        import { SerialController } from './serial';
        import { WebSocketController } from './websocket';

        export function createController() {
            const commMethod = process.env.COMMUNICATION_METHOD || 'serial';

            if (commMethod === 'websocket') {
                return new WebSocketController(8080);
            } else {
                // You might need to dynamically find the Arduino port
                return new SerialController('/dev/tty.usbmodem14201', 9600);
            }
        }
        ```

4.  **Update `node/src/index.ts` to use the factory:**
    *   Import `createController` from `node/src/communication/index.ts`.
    *   Call `createController()` to get the appropriate communication controller.
    *   The rest of the application logic will interact with the controller through the common interface, without needing to know whether it's using Serial or WebSockets.

## Part 3: HTML/Canvas Simulation

This involves creating a front-end application that visualizes the plotter and communicates with the Node.js server via WebSockets.

1.  **Create the Simulation Directory Structure:**
    *   Create a root directory: `simulation/`.
    *   Inside `simulation/`, create:
        *   `index.html`: The main HTML file containing the canvas.
        *   `css/style.css`: For basic styling.
        *   `js/main.js`: The main JavaScript file for the simulation logic.
        *   `js/robot.js`: A module for the robot arm's logic and drawing.
        *   `js/communication.js`: A module for handling WebSocket communication.

2.  **`index.html`:**
    *   A simple HTML5 boilerplate.
    *   A `<canvas>` element for the simulation.
    *   Include the JavaScript files.

3.  **`js/communication.js`:**
    *   This module will handle the WebSocket connection to the Node.js server.
    *   It will have:
        *   A function to initialize the WebSocket connection.
        *   An event handler for `onmessage` to receive commands from the server.
        *   A function to send messages (e.g., state information) back to the server.

4.  **`js/robot.js`:**
    *   This module will define a `Robot` class.
    *   The `Robot` class will maintain the state of the pen plotter:
        *   `angle`: The angle of the swivel joint.
        *   `extension`: The extension of the arm.
        *   `penDown`: A boolean indicating if the pen is down.
    *   It will have methods to:
        *   `update(newState)`: Update the robot's state.
        *   `draw(context)`: Draw the robot on the canvas based on its current state. This will involve `requestAnimationFrame` for smooth animation.
        *   Methods corresponding to the firmware commands (e.g., `setAngle`, `setExtension`, `penUp`, `penDown`). These methods will update the state and trigger a redraw.

5.  **`js/main.js`:**
    *   This will be the entry point for the simulation.
    *   It will:
        *   Initialize the canvas and get its 2D rendering context.
        *   Instantiate the `Robot`.
        *   Initialize the WebSocket connection using the `communication.js` module.
        *   When a command is received from the server, it will call the appropriate method on the `Robot` instance.
        *   Implement the main animation loop using `requestAnimationFrame` to call the `robot.draw()` method on each frame.
        *   Handle sending state back to the server. For example, after a move command is processed, it might send back an `ACK` or the new state of the robot.

## Communication Protocol

The existing communication protocol is a simple, text-based, line-oriented protocol. This protocol will be used for both the refactored `SerialController` and the new `WebSocketController` to ensure compatibility with the Arduino firmware and to keep the controllers' interfaces consistent.

### Commands (Server to Firmware/Simulation)

Commands are sent as a single string, terminated by a newline character (`\n`). The general format is:

`COMMAND_ID,param1,param2,...`

*   `COMMAND_ID`: A short, uppercase string identifying the command (e.g., `ROT`, `IN`, `OUT`).
*   `params`: A comma-separated list of parameters, which can be numbers or strings.

**Examples:**

*   `ROT,900`: Rotate the base by 900 microsteps.
*   `IN,1000`: Retract the arm for 1000 milliseconds.
*   `DIST`: Request the current extension of the arm.

### Responses (Firmware/Simulation to Server)

The server relies on responses for flow control and to get data.

*   **Acknowledgment (`OK`)**: After successfully executing a command, the firmware/simulation MUST send the line `OK\n`. The `sendCommand` function on the server will wait for this acknowledgment before completing.

*   **Data Responses**: For commands that request data (like `DIST` or `ANGL`), the value is sent on a line *before* the final `OK` acknowledgment.

    *   **Example Flow for `DIST`:**
        1.  Server sends: `DIST\n`
        2.  Firmware responds: `150\n` (The current distance)
        3.  Firmware responds: `OK\n`
        4.  The `sendCommand` promise on the server resolves with the value "150".

*   **Errors**: If the firmware encounters an error, it will send a line starting with `ERROR:`.
    *   **Example Flow for an error:**
        1.  Server sends: `UNKNOWN_COMMAND\n`
        2.  Firmware responds: `ERROR: Unknown command received: UNKNOWN_COMMAND\n`
    *   The `sendCommand` promise on the server will be rejected with an error containing this message.

This protocol ensures that commands are executed sequentially and that the server can reliably get state information from the device.
